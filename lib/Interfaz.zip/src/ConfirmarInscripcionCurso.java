import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import static java.awt.Image.SCALE_SMOOTH;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class ConfirmarInscripcionCurso extends JFrame{
    private JPanel Pnl;
    private JLabel Etq, Etq2, Etq3;
    private JLabel Etqt, Etqt2;
    private JTextField txtf;
    private ImageIcon Lg, img1, img2, img3;
    private JButton Btn1, Btn2, Btn3, Btn4, Btn5, Btn6;
    public static void main(String[] args) {
        ConfirmarInscripcionCurso Ap = new ConfirmarInscripcionCurso();//Ap variable de la aplicacion//
        Ap.setVisible(true);
        Ap.setTitle("Confirmar Inscripcion");
    }
    public ConfirmarInscripcionCurso(){
        Panel();
        Logo();
        Imagenes();
        Formulario();
        setSize(1024,720);
        this.setResizable(false);
        setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void Panel(){
        Pnl = new JPanel();
        Pnl.setLayout(null);
        Pnl.setBackground(Color.white);
        this.getContentPane().add(Pnl);
    }
    private void Logo(){
        Etq = new JLabel();
        Etq.setBackground(Color.red);
        Etq.setOpaque(true);
        Etq.setBounds(0, 0, 1024, 56);
        Pnl.add(Etq);
        
        ImageIcon icn1 = new ImageIcon("src/img/Icono5.png");
        JButton Bicn = new JButton();
        Bicn.setBounds(35, 12, 32, 32);
        Bicn.setBackground(null);
        Bicn.setBorder(BorderFactory.createEmptyBorder());
        Bicn.setIcon(new ImageIcon(icn1.getImage().getScaledInstance(Bicn.getWidth(), Bicn.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn);
        
        Lg = new ImageIcon("src/img/Logo1.png");
        JLabel Etqi = new JLabel();
        Etqi.setBounds(448, 12, 100, 32);
        Etqi.setBackground(null);
        Etqi.setBorder(BorderFactory.createEmptyBorder());
        Etqi.setIcon(new ImageIcon(Lg.getImage().getScaledInstance(Etqi.getWidth(), Etqi.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Etqi);
        
        ImageIcon icn2 = new ImageIcon("src/img/Icono4.png");
        JButton Bicn2 = new JButton();
        Bicn2.setBounds(848, 16, 21, 22);
        Bicn2.setBackground(null);
        Bicn2.setBorder(BorderFactory.createEmptyBorder());
        Bicn2.setIcon(new ImageIcon(icn2.getImage().getScaledInstance(Bicn2.getWidth(), Bicn2.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn2);
        
        ImageIcon icn3 = new ImageIcon("src/img/Icono3.png");
        JButton Bicn3 = new JButton();
        Bicn3.setBounds(896, 16, 24, 24);
        Bicn3.setBackground(null);
        Bicn3.setBorder(BorderFactory.createEmptyBorder());
        Bicn3.setIcon(new ImageIcon(icn3.getImage().getScaledInstance(Bicn3.getWidth(), Bicn3.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn3);
        
        ImageIcon icn4 = new ImageIcon("src/img/Icono1.png");
        JButton Bicn4 = new JButton();
        Bicn4.setBounds(944, 16, 7, 23);
        Bicn4.setBackground(null);
        Bicn4.setBorder(BorderFactory.createEmptyBorder());
        Bicn4.setIcon(new ImageIcon(icn4.getImage().getScaledInstance(Bicn4.getWidth(), Bicn4.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn4);
    }
    private void Imagenes(){
        img1 = new ImageIcon("src/img/Boton7.png");
        Btn1 = new JButton();
        Btn1.setBounds(416, 576, 176, 40);
        Btn1.setIcon(new ImageIcon(img1.getImage().getScaledInstance(Btn1.getWidth(), Btn1.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn1);
        ActionListener Ai = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               InscripcionCompleta obj = new InscripcionCompleta();
               obj.setVisible(true);
               dispose();
            }
        };
        Btn1.addActionListener(Ai);
        
        img2 = new ImageIcon("src/img/Imagen7.png");
        Etq2 = new JLabel();
        Etq2.setBounds(288, 80, 416, 130);
        Etq2.setIcon(new ImageIcon(img2.getImage().getScaledInstance(Etq2.getWidth(), Etq2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Etq2);
    }
    private void Formulario(){
        Etqt = new JLabel("Código de inscripcion:");
        Etqt.setFont(new Font("Roboto",0,14));
        Etqt.setBounds(256, 224, 200, 25);
        Etqt.setHorizontalAlignment(SwingConstants.CENTER);
        Pnl.add(Etqt);
        
        Etqt = new JLabel("Si el codigo no llega en 5 min, volver a solicitarlo");
        Etqt.setFont(new Font("Roboto",0,12));
        Etqt.setBounds(368, 448, 272, 25);
        Etqt.setHorizontalAlignment(SwingConstants.CENTER);
        Pnl.add(Etqt);
        
        Etqt = new JLabel("Volver a solicitar codigo de registro");
        Etqt.setForeground(Color.blue);
        Etqt.setFont(new Font("Roboto", 0, 12));
        Etqt.setBounds(376, 512, 256, 25);
        Etqt.setHorizontalAlignment(SwingConstants.CENTER);
        Pnl.add(Etqt);
        
        Etqt2 = new JLabel();
        Etqt2.setBackground(Color.gray);
        Etqt2.setOpaque(true);
        Etqt2.setBounds(288, 256, 480, 2);
        Pnl.add(Etqt2);
        
        img3 = new ImageIcon("src/img/Imagen2.png");
        Etq3 = new JLabel();
        Etq3.setBounds(264, 304, 512, 96);
        Etq3.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Etq3.getWidth(), Etq3.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Etq3);

    }
}
