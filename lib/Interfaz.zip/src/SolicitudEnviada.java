import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import static java.awt.Image.SCALE_SMOOTH;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class SolicitudEnviada extends JFrame{
    private JPanel Pnl;
    private JLabel Etq, Etq2, Etq3;
    private JLabel Etqt;
    private JTextField txtf;
    private ImageIcon Lg, img1, img2, img3;
    private JButton Btn1;
    public static void main(String[] args) {
        SolicitudEnviada Ap = new SolicitudEnviada();//Ap variable de la aplicacion//
        Ap.setVisible(true);
        Ap.setTitle("Solcitar Baja");
    }
    public SolicitudEnviada(){
        Panel();
        Logos();
        Pantalla();
        setSize(1024,720);
        this.setResizable(false);
        setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void Panel(){
        Pnl = new JPanel();
        Pnl.setLayout(null);
        Pnl.setBackground(Color.white);
        this.getContentPane().add(Pnl);
    }
    private void Logos(){
        Etq = new JLabel();
        Etq.setBackground(Color.red);
        Etq.setOpaque(true);
        Etq.setBounds(0, 0, 1024, 56);
        Pnl.add(Etq);
        
        ImageIcon icn1 = new ImageIcon("src/img/Icono5.png");
        JButton Bicn = new JButton();
        Bicn.setBounds(35, 12, 32, 32);
        Bicn.setBackground(null);
        Bicn.setBorder(BorderFactory.createEmptyBorder());
        Bicn.setIcon(new ImageIcon(icn1.getImage().getScaledInstance(Bicn.getWidth(), Bicn.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn);
        
        Lg = new ImageIcon("src/img/Logo1.png");
        JLabel Etqi = new JLabel();
        Etqi.setBounds(448, 12, 100, 32);
        Etqi.setBackground(null);
        Etqi.setBorder(BorderFactory.createEmptyBorder());
        Etqi.setIcon(new ImageIcon(Lg.getImage().getScaledInstance(Etqi.getWidth(), Etqi.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Etqi);
        
        ImageIcon icn2 = new ImageIcon("src/img/Icono4.png");
        JButton Bicn2 = new JButton();
        Bicn2.setBounds(848, 16, 21, 22);
        Bicn2.setBackground(null);
        Bicn2.setBorder(BorderFactory.createEmptyBorder());
        Bicn2.setIcon(new ImageIcon(icn2.getImage().getScaledInstance(Bicn2.getWidth(), Bicn2.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn2);
        
        ImageIcon icn3 = new ImageIcon("src/img/Icono3.png");
        JButton Bicn3 = new JButton();
        Bicn3.setBounds(896, 16, 24, 24);
        Bicn3.setBackground(null);
        Bicn3.setBorder(BorderFactory.createEmptyBorder());
        Bicn3.setIcon(new ImageIcon(icn3.getImage().getScaledInstance(Bicn3.getWidth(), Bicn3.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn3);
        
        ImageIcon icn4 = new ImageIcon("src/img/Icono1.png");
        JButton Bicn4 = new JButton();
        Bicn4.setBounds(944, 16, 7, 23);
        Bicn4.setBackground(null);
        Bicn4.setBorder(BorderFactory.createEmptyBorder());
        Bicn4.setIcon(new ImageIcon(icn4.getImage().getScaledInstance(Bicn4.getWidth(), Bicn4.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn4);
        
        Etq2 = new JLabel();
        Etq2.setBackground(Color.red);
        Etq2.setOpaque(true);
        Etq2.setBounds(0, 640, 1024, 44);
        Pnl.add(Etq2);
    }
    private void Pantalla(){    
        Etqt = new JLabel();
        Etqt.setBackground(Color.gray);
        Etqt.setOpaque(true);
        Etqt.setBounds(0, 128, 1024, 2);
        Pnl.add(Etqt);
        
        Etqt = new JLabel();
        Etqt.setBackground(Color.gray);
        Etqt.setOpaque(true);
        Etqt.setBounds(0, 608, 1024, 2);
        Pnl.add(Etqt);
        
        Etq2 = new JLabel("¡Se ha enviado la solicitud de baja del curso!");
        Etq2.setFont(new Font("Arial",0,18));
        Etq2.setBounds(320, 192, 384, 24);
        Pnl.add(Etq2);
        
        Etq3 = new JLabel("Se le notificara al docente");
        Etq3.setFont(new Font("Arial",0,13));
        Etq3.setBounds(416, 288, 384, 24);
        Pnl.add(Etq3);
        
        img1 = new ImageIcon("src/img/Boton7.png");
        Btn1 = new JButton();
        Btn1.setBounds(408, 488, 176, 40);
        Btn1.setIcon(new ImageIcon(img1.getImage().getScaledInstance(Btn1.getWidth(), Btn1.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn1);
    }
}
