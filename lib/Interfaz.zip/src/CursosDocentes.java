import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class CursosDocentes extends JFrame{
    private JPanel Pnl;
    private JLabel Etq, Etq2, Etq3;
    private ImageIcon Lg, icn1, icn2, icn3, icn4;
    private JButton Btn, Btn2;
    private ImageIcon img, img2, img3, img4;
    private JLabel Et, Et2;
    
    public static void main(String[] args) {
        CursosDocentes Ap = new CursosDocentes();//Ap variable de la aplicacion//
        Ap.setVisible(true);
        Ap.setTitle("Cursos");
    }
    public CursosDocentes(){
        Panel();
        Logo();
        Menu();
        setSize(1024,720);
        this.setResizable(false);
        setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void Panel(){
        Pnl = new JPanel();
        Pnl.setLayout(null);
        Pnl.setBackground(Color.white);
        this.getContentPane().add(Pnl);
    }
    private void Logo(){
        Etq = new JLabel();
        Etq.setBackground(Color.red);
        Etq.setOpaque(true);
        Etq.setBounds(0, 0, 1024, 56);
        Pnl.add(Etq);
        
        icn1 = new ImageIcon("src/img/Icono5.png");
        JButton Bicn = new JButton();
        Bicn.setBounds(35, 12, 32, 32);
        Bicn.setBackground(null);
        Bicn.setBorder(BorderFactory.createEmptyBorder());
        Bicn.setIcon(new ImageIcon(icn1.getImage().getScaledInstance(Bicn.getWidth(), Bicn.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn);
        
        Lg = new ImageIcon("src/img/Logo1.png");
        JLabel Etqi = new JLabel();
        Etqi.setBounds(448, 12, 100, 32);
        Etqi.setBackground(null);
        Etqi.setBorder(BorderFactory.createEmptyBorder());
        Etqi.setIcon(new ImageIcon(Lg.getImage().getScaledInstance(Etqi.getWidth(), Etqi.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Etqi);
        
        icn2 = new ImageIcon("src/img/Icono4.png");
        JButton Bicn2 = new JButton();
        Bicn2.setBounds(848, 16, 21, 22);
        Bicn2.setBackground(null);
        Bicn2.setBorder(BorderFactory.createEmptyBorder());
        Bicn2.setIcon(new ImageIcon(icn2.getImage().getScaledInstance(Bicn2.getWidth(), Bicn2.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn2);
        
        icn3 = new ImageIcon("src/img/Icono3.png");
        JButton Bicn3 = new JButton();
        Bicn3.setBounds(896, 16, 24, 24);
        Bicn3.setBackground(null);
        Bicn3.setBorder(BorderFactory.createEmptyBorder());
        Bicn3.setIcon(new ImageIcon(icn3.getImage().getScaledInstance(Bicn3.getWidth(), Bicn3.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn3);
        
        icn4 = new ImageIcon("src/img/Icono1.png");
        JButton Bicn4 = new JButton();
        Bicn4.setBounds(944, 16, 7, 23);
        Bicn4.setBackground(null);
        Bicn4.setBorder(BorderFactory.createEmptyBorder());
        Bicn4.setIcon(new ImageIcon(icn4.getImage().getScaledInstance(Bicn4.getWidth(), Bicn4.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn4);
    }
    private void Menu(){
        Etq2 = new JLabel("Cursos");
        Etq2.setFont(new Font("Roboto",0,18));
        Etq2.setBounds(456, 96, 100, 24);
        Pnl.add(Etq2);
        
        Etq2 = new JLabel("Todos los cursos");
        Etq2.setFont(new Font("Tahoma",1,12));
        Etq2.setBounds(192, 144, 112, 24);
        Pnl.add(Etq2);
        
        img = new ImageIcon("src/img/Imagen3.png");
        Et = new JLabel();
        Et.setBounds(192, 168, 640, 28);
        Et.setIcon(new ImageIcon(img.getImage().getScaledInstance(Et.getWidth(), Et.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Et);
        
        img2 = new ImageIcon("src/img/Imagen4.png");
        Et2 = new JLabel();
        Et2.setBorder(BorderFactory.createLineBorder(Color.black,1));
        Et2.setBounds(192, 194, 504, 356);
        Et2.setIcon(new ImageIcon(img2.getImage().getScaledInstance(Et2.getWidth(), Et2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Et2);
        
        img3 = new ImageIcon("src/img/Icono6.png");
        Btn2 = new JButton();
        Btn2.setBounds(704, 205, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono6.png");
        Btn2 = new JButton();
        Btn2.setBounds(704, 256, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono6.png");
        Btn2 = new JButton();
        Btn2.setBounds(704, 307, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono6.png");
        Btn2 = new JButton();
        Btn2.setBounds(704, 358, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono6.png");
        Btn2 = new JButton();
        Btn2.setBounds(704, 409, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono6.png");
        Btn2 = new JButton();
        Btn2.setBounds(704, 460, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono6.png");
        Btn2 = new JButton();
        Btn2.setBounds(704, 511, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono7.png");
        Btn2 = new JButton();
        Btn2.setBounds(736, 205, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        ActionListener Ai = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               DetalleCursoDc obj = new DetalleCursoDc();
               obj.setVisible(true);
               dispose();
            }
        };
        Btn2.addActionListener(Ai);
        
        img3 = new ImageIcon("src/img/Icono7.png");
        Btn2 = new JButton();
        Btn2.setBounds(736, 256, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono7.png");
        Btn2 = new JButton();
        Btn2.setBounds(736, 307, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono7.png");
        Btn2 = new JButton();
        Btn2.setBounds(736, 358, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono7.png");
        Btn2 = new JButton();
        Btn2.setBounds(736, 409, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono7.png");
        Btn2 = new JButton();
        Btn2.setBounds(736, 460, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono7.png");
        Btn2 = new JButton();
        Btn2.setBounds(736, 511, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono8.png");
        Btn2 = new JButton();
        Btn2.setBounds(768, 205, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono8.png");
        Btn2 = new JButton();
        Btn2.setBounds(768, 256, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono8.png");
        Btn2 = new JButton();
        Btn2.setBounds(768, 307, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono8.png");
        Btn2 = new JButton();
        Btn2.setBounds(768, 358, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono8.png");
        Btn2 = new JButton();
        Btn2.setBounds(768, 409, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono8.png");
        Btn2 = new JButton();
        Btn2.setBounds(768, 460, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono8.png");
        Btn2 = new JButton();
        Btn2.setBounds(768, 511, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono9.png");
        Btn2 = new JButton();
        Btn2.setBounds(800, 205, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono9.png");
        Btn2 = new JButton();
        Btn2.setBounds(800, 256, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono9.png");
        Btn2 = new JButton();
        Btn2.setBounds(800, 307, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono9.png");
        Btn2 = new JButton();
        Btn2.setBounds(800, 358, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono9.png");
        Btn2 = new JButton();
        Btn2.setBounds(800, 409, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono9.png");
        Btn2 = new JButton();
        Btn2.setBounds(800, 460, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Icono9.png");
        Btn2 = new JButton();
        Btn2.setBounds(800, 511, 32, 32);
        Btn2.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img4 = new ImageIcon("src/img/Boton9.png");
        Btn = new JButton();
        Btn.setBounds(712, 603, 112, 32);
        Btn.setIcon(new ImageIcon(img4.getImage().getScaledInstance(Btn.getWidth(), Btn.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn);
        
        img4 = new ImageIcon("src/img/Boton10.png");
        Btn = new JButton();
        Btn.setBounds(160, 592, 32, 32);
        Btn.setIcon(new ImageIcon(img4.getImage().getScaledInstance(Btn.getWidth(), Btn.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn);
    }  
}
