import java.awt.Color;
import static java.awt.Component.RIGHT_ALIGNMENT;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class SolicitarBajaCurso extends JFrame{
    private JPanel Pnl;
    private JLabel Etq, Etq2, Etq3, Etq4;
    private JTextField txtf;
    private JTextArea txta;
    private ImageIcon Lg, icn1, icn2, icn3, icn4;
    private JButton Btn, Btn2, Btn3, Btn4;
    private ImageIcon img, img2, img3;
    
    public static void main(String[] args) {
        SolicitarBajaCurso Ap = new SolicitarBajaCurso();//Ap variable de la aplicacion//
        Ap.setVisible(true);
        Ap.setTitle("Solicitar Baja");
    }
    public SolicitarBajaCurso(){
        Panel();
        Logo();
        Formulario();
        setSize(1024,720);
        this.setResizable(false);
        setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void Panel(){
        Pnl = new JPanel();
        Pnl.setLayout(null);
        Pnl.setBackground(Color.white);
        this.getContentPane().add(Pnl);
    }
    private void Logo(){
        Etq = new JLabel();
        Etq.setBackground(Color.red);
        Etq.setOpaque(true);
        Etq.setBounds(0, 0, 1024, 56);
        Pnl.add(Etq);
        
        icn1 = new ImageIcon("src/img/Icono5.png");
        JButton Bicn = new JButton();
        Bicn.setBounds(35, 12, 32, 32);
        Bicn.setBackground(null);
        Bicn.setBorder(BorderFactory.createEmptyBorder());
        Bicn.setIcon(new ImageIcon(icn1.getImage().getScaledInstance(Bicn.getWidth(), Bicn.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn);
        
        Lg = new ImageIcon("src/img/Logo1.png");
        JLabel Etqi = new JLabel();
        Etqi.setBounds(448, 12, 100, 32);
        Etqi.setBackground(null);
        Etqi.setBorder(BorderFactory.createEmptyBorder());
        Etqi.setIcon(new ImageIcon(Lg.getImage().getScaledInstance(Etqi.getWidth(), Etqi.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Etqi);
        
        icn2 = new ImageIcon("src/img/Icono4.png");
        JButton Bicn2 = new JButton();
        Bicn2.setBounds(848, 16, 21, 22);
        Bicn2.setBackground(null);
        Bicn2.setBorder(BorderFactory.createEmptyBorder());
        Bicn2.setIcon(new ImageIcon(icn2.getImage().getScaledInstance(Bicn2.getWidth(), Bicn2.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn2);
        
        icn3 = new ImageIcon("src/img/Icono3.png");
        JButton Bicn3 = new JButton();
        Bicn3.setBounds(896, 16, 24, 24);
        Bicn3.setBackground(null);
        Bicn3.setBorder(BorderFactory.createEmptyBorder());
        Bicn3.setIcon(new ImageIcon(icn3.getImage().getScaledInstance(Bicn3.getWidth(), Bicn3.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn3);
        
        icn4 = new ImageIcon("src/img/Icono1.png");
        JButton Bicn4 = new JButton();
        Bicn4.setBounds(944, 16, 7, 23);
        Bicn4.setBackground(null);
        Bicn4.setBorder(BorderFactory.createEmptyBorder());
        Bicn4.setIcon(new ImageIcon(icn4.getImage().getScaledInstance(Bicn4.getWidth(), Bicn4.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn4);
    }
    private void Formulario(){
        Etq2 = new JLabel();
        Etq2.setText("Solicitar Baja del Curso");
        Etq2.setFont(new Font("Roboto",0,18));
        Etq2.setBounds(384, 80, 200, 25);
        Etq2.setHorizontalAlignment(SwingConstants.CENTER);
        Pnl.add(Etq2);
        
        Etq3 = new JLabel();
        Etq3.setText("*Matrícula:");
        Etq3.setFont(new Font("Roboto",0,12));
        Etq3.setBounds(0, 128, 200, 25);
        Etq3.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etq3);
        
        txtf = new JTextField();
        txtf.setBounds(216, 132, 240, 18);
        Pnl.add(txtf);
        
        Etq3 = new JLabel();
        Etq3.setText("*Nombre:");
        Etq3.setFont(new Font("Roboto",0,12));
        Etq3.setBounds(0, 160, 200, 25);
        Etq3.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etq3);
        
        txtf = new JTextField();
        txtf.setBounds(216, 164, 240, 18);
        Pnl.add(txtf);
        
        Etq3 = new JLabel();
        Etq3.setText("*Correo electronico:");
        Etq3.setFont(new Font("Roboto",0,12));
        Etq3.setBounds(0, 192, 200, 25);
        Etq3.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etq3);
        
        txtf = new JTextField();
        txtf.setBounds(216, 196, 240, 18);
        Pnl.add(txtf);
        
        Etq3 = new JLabel();
        Etq3.setText("*Confirmar Correo:");
        Etq3.setFont(new Font("Roboto",0,12));
        Etq3.setBounds(0, 224, 200, 25);
        Etq3.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etq3);
        
        txtf = new JTextField();
        txtf.setBounds(216, 228, 240, 18);
        Pnl.add(txtf);
        
        Etq3 = new JLabel();
        Etq3.setText("*Nombre del Curso:");
        Etq3.setFont(new Font("Roboto",0,12));
        Etq3.setBounds(0, 256, 200, 25);
        Etq3.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etq3);
        
        txtf = new JTextField();
        txtf.setBounds(216, 260, 240, 18);
        Pnl.add(txtf);
        
        Etq3 = new JLabel();
        Etq3.setText("*Nombre del Docente:");
        Etq3.setFont(new Font("Roboto",0,12));
        Etq3.setBounds(0, 288, 200, 25);
        Etq3.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etq3);
        
        txtf = new JTextField();
        txtf.setBounds(216, 292, 240, 18);
        Pnl.add(txtf);
        
        Etq3 = new JLabel();
        Etq3.setText("*Motivo:");
        Etq3.setFont(new Font("Roboto",0,12));
        Etq3.setBounds(0, 320, 200, 25);
        Etq3.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etq3);
        
        txta = new JTextArea();
        txta.setBounds(216, 330, 232, 144);
        txta.setBorder(BorderFactory.createLineBorder(Color.black,1));
        Pnl.add(txta);
        
        Etq3 = new JLabel();
        Etq3.setText("*Campos Obligatorios");
        Etq3.setFont(new Font("Roboto",0,9));
        Etq3.setBounds(96, 352, 200, 25);
        Pnl.add(Etq3);
        
        Etq4 = new JLabel();
        Etq4.setBackground(Color.gray);
        Etq4.setOpaque(true);
        Etq4.setBounds(128, 512, 768, 2);
        Pnl.add(Etq4);
        
        img = new ImageIcon("src/img/Boton11.png");
        Btn = new JButton();
        Btn.setBounds(384, 592, 128, 40);
        Btn.setIcon(new ImageIcon(img.getImage().getScaledInstance(Btn.getWidth(), Btn.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn);
        ActionListener Ai2 = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               DetalleCurso2Al obj = new DetalleCurso2Al();
               obj.setVisible(true);
               dispose();
            }
        };
        Btn.addActionListener(Ai2);
        
        img2 = new ImageIcon("src/img/Boton19.png");
        Btn = new JButton();
        Btn.setBounds(544, 592, 128, 40);
        Btn.setIcon(new ImageIcon(img2.getImage().getScaledInstance(Btn.getWidth(), Btn.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn);
        ActionListener Ai = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               SolicitudEnviada obj = new SolicitudEnviada();
               obj.setVisible(true);
               dispose();
            }
        };
        Btn.addActionListener(Ai);
        
        img3 = new ImageIcon("src/img/Boton10.png");
        Btn3 = new JButton();
        Btn3.setBounds(64, 608, 32, 32);
        Btn3.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn3.getWidth(), Btn3.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn3);
    }
}