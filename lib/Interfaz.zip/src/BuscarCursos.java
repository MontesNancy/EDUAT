import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class BuscarCursos extends JFrame{
    private JPanel Pnl;
    private JLabel Etq, Etq2, Etq3;
    private ImageIcon Lg, icn1, icn2, icn3, icn4;
    private JButton Btn, Btn2;
    private ImageIcon img, img2, img3, img4;
    private JLabel Et, Et2;
    
    public static void main(String[] args) {
        BuscarCursos Ap = new BuscarCursos();//Ap variable de la aplicacion//
        Ap.setVisible(true);
        Ap.setTitle("Buscar Cursos");
    }
    public BuscarCursos(){
        Panel();
        Logo();
        Menu();
        setSize(1024,720);
        this.setResizable(false);
        setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void Panel(){
        Pnl = new JPanel();
        Pnl.setLayout(null);
        Pnl.setBackground(Color.white);
        this.getContentPane().add(Pnl);
    }
    private void Logo(){
        Etq = new JLabel();
        Etq.setBackground(Color.red);
        Etq.setOpaque(true);
        Etq.setBounds(0, 0, 1024, 56);
        Pnl.add(Etq);
        
        icn1 = new ImageIcon("src/img/Icono5.png");
        JButton Bicn = new JButton();
        Bicn.setBounds(35, 12, 32, 32);
        Bicn.setBackground(null);
        Bicn.setBorder(BorderFactory.createEmptyBorder());
        Bicn.setIcon(new ImageIcon(icn1.getImage().getScaledInstance(Bicn.getWidth(), Bicn.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn);
        
        Lg = new ImageIcon("src/img/Logo1.png");
        JLabel Etqi = new JLabel();
        Etqi.setBounds(448, 12, 100, 32);
        Etqi.setBackground(null);
        Etqi.setBorder(BorderFactory.createEmptyBorder());
        Etqi.setIcon(new ImageIcon(Lg.getImage().getScaledInstance(Etqi.getWidth(), Etqi.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Etqi);
        
        icn2 = new ImageIcon("src/img/Icono4.png");
        JButton Bicn2 = new JButton();
        Bicn2.setBounds(848, 16, 21, 22);
        Bicn2.setBackground(null);
        Bicn2.setBorder(BorderFactory.createEmptyBorder());
        Bicn2.setIcon(new ImageIcon(icn2.getImage().getScaledInstance(Bicn2.getWidth(), Bicn2.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn2);
        
        icn3 = new ImageIcon("src/img/Icono3.png");
        JButton Bicn3 = new JButton();
        Bicn3.setBounds(896, 16, 24, 24);
        Bicn3.setBackground(null);
        Bicn3.setBorder(BorderFactory.createEmptyBorder());
        Bicn3.setIcon(new ImageIcon(icn3.getImage().getScaledInstance(Bicn3.getWidth(), Bicn3.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn3);
        
        icn4 = new ImageIcon("src/img/Icono1.png");
        JButton Bicn4 = new JButton();
        Bicn4.setBounds(944, 16, 7, 23);
        Bicn4.setBackground(null);
        Bicn4.setBorder(BorderFactory.createEmptyBorder());
        Bicn4.setIcon(new ImageIcon(icn4.getImage().getScaledInstance(Bicn4.getWidth(), Bicn4.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn4);
    }
    private void Menu(){
        Etq2 = new JLabel("Buscar Cursos");
        Etq2.setFont(new Font("Roboto",0,18));
        Etq2.setBounds(456, 96, 128, 24);
        Pnl.add(Etq2);
        
        Etq2 = new JLabel("Cursos Disponibles");
        Etq2.setFont(new Font("Tahoma",1,12));
        Etq2.setBounds(192, 144, 192, 24);
        Pnl.add(Etq2);
        
        JLabel txt = new JLabel("Semestre:");
        txt.setFont(new Font("Arial",0,12));
        txt.setBounds(608, 144, 80, 20);
        Pnl.add(txt);
        
        Choice Ch = new Choice();
        Ch.add("Seleccionar");
        Ch.add("Semestre 1");
        Ch.add("Semestre 3");
        Ch.add("Semestre 5");
        Ch.add("Semestre 7");
        Ch.add("Semestre 9");
        Ch.setBounds(704, 144, 128, 20);
        Pnl.add(Ch);
        
        img = new ImageIcon("src/img/Imagen5.png");
        Et = new JLabel();
        Et.setBounds(192, 168, 640, 28);
        Et.setIcon(new ImageIcon(img.getImage().getScaledInstance(Et.getWidth(), Et.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Et);
        
        img2 = new ImageIcon("src/img/Imagen6.png");
        Et2 = new JLabel();
        Et2.setBorder(BorderFactory.createLineBorder(Color.black,1));
        Et2.setBounds(192, 194, 504, 356);
        Et2.setIcon(new ImageIcon(img2.getImage().getScaledInstance(Et2.getWidth(), Et2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Et2);
        
        img3 = new ImageIcon("src/img/Boton12.png");
        JButton Btn3 = new JButton();
        Btn3.setBounds(704, 205, 112, 30);
        Btn3.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn3.getWidth(), Btn3.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn3);
        
        ActionListener Ai = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               DetalleCurso1Al obj = new DetalleCurso1Al();
               obj.setVisible(true);
               dispose();
            }
        };
        Btn3.addActionListener(Ai);
        
        img3 = new ImageIcon("src/img/Boton12.png");
        JButton Btn4 = new JButton();
        Btn4.setBounds(704, 256, 112, 30);
        Btn4.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn4.getWidth(), Btn4.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn4);
        
        img3 = new ImageIcon("src/img/Boton12.png");
        JButton Btn5 = new JButton();
        Btn5.setBounds(704, 307, 112, 30);
        Btn5.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn5.getWidth(), Btn5.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn5);
        
        img3 = new ImageIcon("src/img/Boton12.png");
        JButton Btn6 = new JButton();
        Btn6.setBounds(704, 358, 112, 30);
        Btn6.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn6.getWidth(), Btn6.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn6);
        
        img3 = new ImageIcon("src/img/Boton12.png");
        JButton Btn7 = new JButton();
        Btn7.setBounds(704, 409, 112, 30);
        Btn7.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn7.getWidth(), Btn7.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn7);
        
        img3 = new ImageIcon("src/img/Boton12.png");
        JButton Btn8 = new JButton();
        Btn8.setBounds(704, 460, 112, 30);
        Btn8.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn8.getWidth(), Btn8.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn8);
        
        img3 = new ImageIcon("src/img/Boton12.png");
        JButton Btn9 = new JButton();
        Btn9.setBounds(704, 511, 112, 30);
        Btn9.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn9.getWidth(), Btn9.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn9);
        
        img4 = new ImageIcon("src/img/Boton9.png");
        Btn = new JButton();
        Btn.setBounds(712, 603, 112, 32);
        Btn.setIcon(new ImageIcon(img4.getImage().getScaledInstance(Btn.getWidth(), Btn.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn);
        
        img4 = new ImageIcon("src/img/Boton10.png");
        Btn2 = new JButton();
        Btn2.setBounds(160, 592, 32, 32);
        Btn2.setIcon(new ImageIcon(img4.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
    }  
}
