import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import static java.awt.Image.SCALE_SMOOTH;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class RegistroDocentes extends JFrame{
    private JPanel Pnl;
    private JLabel Etq, Etq2, Etq3;
    private JLabel Etqt, Etqt2;
    private JTextField txtf;
    private ImageIcon Lg, img1, img2, img3, img4, img5, img6, img7;
    private JButton Btn1, Btn2, Btn3, Btn4, Btn5, Btn6;
    public static void main(String[] args) {
        RegistroDocentes Ap = new RegistroDocentes();//Ap variable de la aplicacion//
        Ap.setVisible(true);
        Ap.setTitle("Registro Docentes");
    }
    public RegistroDocentes(){
        Panel();
        Logos();
        Imagenes();
        Formulario();
        setSize(1024,720);
        this.setResizable(false);
        setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void Panel(){
        Pnl = new JPanel();
        Pnl.setLayout(null);
        Pnl.setBackground(Color.white);
        this.getContentPane().add(Pnl);
    }
    private void Logos(){
        Etq = new JLabel();
        Etq.setBackground(Color.red);
        Etq.setOpaque(true);
        Etq.setBounds(0, 0, 1024, 56);
        Pnl.add(Etq);
        
        Lg = new ImageIcon("src/img/Logo1.png");
        JButton Blg = new JButton();
        Blg.setBounds(35, 12, 100, 32);
        Blg.setBackground(null);
        Blg.setBorder(BorderFactory.createEmptyBorder());
        Blg.setIcon(new ImageIcon(Lg.getImage().getScaledInstance(Blg.getWidth(), Blg.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Blg);
        
        JTextField tf = new JTextField(" Buscar aqui");
        tf.setFont(new Font("Roboto",0,11));
        tf.setEnabled(false);
        tf.setBounds(576, 18, 320, 20);
        Etq.add(tf);
        
        ImageIcon Icn = new ImageIcon("Icono1.png");
        JButton Ic = new JButton();
        Ic.setBounds(912, 16, 7, 23);
        Ic.setBackground(null);
        Ic.setBorder(BorderFactory.createEmptyBorder());
        Ic.setIcon(new ImageIcon(Icn.getImage().getScaledInstance(Ic.getWidth(), Ic.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Ic);
        
        Etq2 = new JLabel();
        Etq2.setBackground(Color.red);
        Etq2.setOpaque(true);
        Etq2.setBounds(0, 640, 1024, 44);
        Pnl.add(Etq2);
    }
    private void Imagenes(){
        img1 = new ImageIcon("src/img/Boton1.png");
        Btn1 = new JButton();
        Btn1.setBounds(304, 472, 192, 38);
        Btn1.setIcon(new ImageIcon(img1.getImage().getScaledInstance(Btn1.getWidth(), Btn1.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn1);
        
        img2 = new ImageIcon("src/img/Boton2.png");
        Btn2 = new JButton();
        Btn2.setBounds(528, 472, 192, 38);
        Btn2.setIcon(new ImageIcon(img2.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Boton3.png");
        Btn3 = new JButton();
        Btn3.setBounds(304, 528, 192, 38);
        Btn3.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn3.getWidth(), Btn3.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn3);
        
        img4 = new ImageIcon("src/img/Boton4.png");
        Btn4 = new JButton();
        Btn4.setBounds(528, 528, 192, 38);
        Btn4.setIcon(new ImageIcon(img4.getImage().getScaledInstance(Btn4.getWidth(), Btn4.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn4);
        
        img5 = new ImageIcon("src/img/Boton5.png");
        Btn5 = new JButton();
        Btn5.setBounds(368, 592, 128, 24);
        Btn5.setIcon(new ImageIcon(img5.getImage().getScaledInstance(Btn5.getWidth(), Btn5.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn5);
        
        img6 = new ImageIcon("src/img/Boton6.png");
        Btn6 = new JButton();
        Btn6.setBounds(528, 592, 128, 24);
        Btn6.setIcon(new ImageIcon(img6.getImage().getScaledInstance(Btn6.getWidth(), Btn6.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn6);
        
        ActionListener Ai = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               ConfirmarRegistro obj = new ConfirmarRegistro();
               obj.setVisible(true);
               dispose();
            }
        };
        Btn6.addActionListener(Ai);
        
        
        img7 = new ImageIcon("src/img/Icono2.png");
        Etq3 = new JLabel();
        Etq3.setBounds(432, 112, 96, 88);
        Etq3.setIcon(new ImageIcon(img7.getImage().getScaledInstance(Etq3.getWidth(), Etq3.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Etq3);
    }
    private void Formulario(){
        Etqt = new JLabel();
        Etqt.setText("Registro Docentes");
        Etqt.setFont(new Font("Roboto",0,18));
        Etqt.setBounds(352, 64, 200, 25);
        Etqt.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etqt);
        
        Etqt2 = new JLabel("*Nombre(s):");
        Etqt2.setFont(new Font("Roboto",0,12));
        Etqt2.setBounds(208, 224, 200, 25);
        Etqt2.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etqt2);
        
        Etqt2 = new JLabel("*Apellidos(s):");
        Etqt2.setFont(new Font("Roboto",0,12));
        Etqt2.setBounds(208, 248, 200, 25);
        Etqt2.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etqt2);
        
        Etqt2 = new JLabel("*Correo Institucional:");
        Etqt2.setFont(new Font("Roboto",0,12));
        Etqt2.setBounds(208, 272, 200, 25);
        Etqt2.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etqt2);
        
        Etqt2 = new JLabel("*Correo Electrónico:");
        Etqt2.setFont(new Font("Roboto",0,12));
        Etqt2.setBounds(208, 296, 200, 25);
        Etqt2.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etqt2);
        
        Etqt2 = new JLabel("*Confirmar Correo:");
        Etqt2.setFont(new Font("Roboto",0,12));
        Etqt2.setBounds(208, 320, 200, 25);
        Etqt2.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etqt2);
        
        Etqt2 = new JLabel("*Nombre de usuario:");
        Etqt2.setFont(new Font("Roboto",0,12));
        Etqt2.setBounds(208, 344, 200, 25);
        Etqt2.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etqt2);
        
        Etqt2 = new JLabel("*Contraseña:");
        Etqt2.setFont(new Font("Roboto",0,12));
        Etqt2.setBounds(208, 368, 200, 25);
        Etqt2.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etqt2);
        
        Etqt2 = new JLabel("*Confirmar contraseña:");
        Etqt2.setFont(new Font("Roboto",0,12));
        Etqt2.setBounds(208, 392, 200, 25);
        Etqt2.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etqt2);
        
        Etqt2 = new JLabel("*Campos Obligatorios");
        Etqt2.setFont(new Font("Roboto",0,10));
        Etqt2.setBounds(272, 424, 200, 25);
        Etqt2.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etqt2);
        
        Etqt2 = new JLabel();
        Etqt2.setBackground(Color.gray);
        Etqt2.setOpaque(true);
        Etqt2.setBounds(256, 460, 512, 2);
        Pnl.add(Etqt2);
        
        txtf = new JTextField();
        txtf.setBounds(424, 228, 240, 18);
        Pnl.add(txtf);
        
        txtf = new JTextField();
        txtf.setBounds(424, 252, 240, 18);
        Pnl.add(txtf);
        
        txtf = new JTextField();
        txtf.setBounds(424, 276, 240, 18);
        Pnl.add(txtf);
        
        txtf = new JTextField();
        txtf.setBounds(424, 300, 240, 18);
        Pnl.add(txtf);
        
        txtf = new JTextField();
        txtf.setBounds(424, 324, 240, 18);
        Pnl.add(txtf);
        
        txtf = new JTextField();
        txtf.setBounds(424, 348, 240, 18);
        Pnl.add(txtf);
        
        txtf = new JTextField();
        txtf.setBounds(424, 372, 240, 18);
        Pnl.add(txtf);
        
        txtf = new JTextField();
        txtf.setBounds(424, 396, 240, 18);
        Pnl.add(txtf);
    }
}
