import java.awt.Choice;
import java.awt.Color;
import static java.awt.Component.RIGHT_ALIGNMENT;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

public class DetalleCurso2Al extends JFrame{
    private JPanel Pnl;
    private JLabel Etq, Etq2;
    private ImageIcon Lg, icn1, icn2, icn3, icn4;
    private JButton Btn, Btn2, Btn3, Btn4, Btn5;
    private ImageIcon img;
    
    public static void main(String[] args) {
        DetalleCurso2Al Ap = new DetalleCurso2Al();//Ap variable de la aplicacion//
        Ap.setVisible(true);
        Ap.setTitle("Curso");
        Ap.setSize(1024,720);
        Ap.setLocationRelativeTo(null);
        Ap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public DetalleCurso2Al(){
        Panel();
        Logo();
        Detalle();
        setSize(1024,720);
        this.setResizable(false);
        setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void Panel(){
        Pnl = new JPanel();
        Pnl.setLayout(null);
        Pnl.setBackground(Color.white);
        this.getContentPane().add(Pnl);
    }
    private void Logo(){
        Etq = new JLabel();
        Etq.setBackground(Color.red);
        Etq.setOpaque(true);
        Etq.setBounds(0, 0, 1024, 56);
        Pnl.add(Etq);
        
        icn1 = new ImageIcon("src/img/Icono5.png");
        JButton Bicn = new JButton();
        Bicn.setBounds(35, 12, 32, 32);
        Bicn.setBackground(null);
        Bicn.setBorder(BorderFactory.createEmptyBorder());
        Bicn.setIcon(new ImageIcon(icn1.getImage().getScaledInstance(Bicn.getWidth(), Bicn.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn);
        
        Lg = new ImageIcon("src/img/Logo1.png");
        JLabel Etqi = new JLabel();
        Etqi.setBounds(448, 12, 100, 32);
        Etqi.setBackground(null);
        Etqi.setBorder(BorderFactory.createEmptyBorder());
        Etqi.setIcon(new ImageIcon(Lg.getImage().getScaledInstance(Etqi.getWidth(), Etqi.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Etqi);
        
        icn2 = new ImageIcon("src/img/Icono4.png");
        JButton Bicn2 = new JButton();
        Bicn2.setBounds(848, 16, 21, 22);
        Bicn2.setBackground(null);
        Bicn2.setBorder(BorderFactory.createEmptyBorder());
        Bicn2.setIcon(new ImageIcon(icn2.getImage().getScaledInstance(Bicn2.getWidth(), Bicn2.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn2);
        
        icn3 = new ImageIcon("src/img/Icono3.png");
        JButton Bicn3 = new JButton();
        Bicn3.setBounds(896, 16, 24, 24);
        Bicn3.setBackground(null);
        Bicn3.setBorder(BorderFactory.createEmptyBorder());
        Bicn3.setIcon(new ImageIcon(icn3.getImage().getScaledInstance(Bicn3.getWidth(), Bicn3.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn3);
        
        icn4 = new ImageIcon("src/img/Icono1.png");
        JButton Bicn4 = new JButton();
        Bicn4.setBounds(944, 16, 7, 23);
        Bicn4.setBackground(null);
        Bicn4.setBorder(BorderFactory.createEmptyBorder());
        Bicn4.setIcon(new ImageIcon(icn4.getImage().getScaledInstance(Bicn4.getWidth(), Bicn4.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Bicn4);
    }
    private void Detalle(){
        Etq = new JLabel("Detalle del curso");
        Etq.setFont(new Font("Roboto",0,18));
        Etq.setBounds(440, 96, 176, 24);
        Pnl.add(Etq);
        
        Etq2 = new JLabel("Bases de datos");
        Etq2.setFont(new Font("Tahoma",1,12));
        Etq2.setBounds(96, 128, 192, 24);
        Pnl.add(Etq2);
        
        img = new ImageIcon("src/img/Imagen8.png");
        JLabel Eti = new JLabel();
        Eti.setBorder(BorderFactory.createLineBorder(Color.black,1));
        Eti.setBounds(64, 160, 288, 160);
        Eti.setIcon(new ImageIcon(img.getImage().getScaledInstance(Eti.getWidth(), Eti.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Eti);
        
        img = new ImageIcon("src/img/Imagen9.png");
        JLabel Eti2 = new JLabel();
        Eti2.setBorder(BorderFactory.createLineBorder(Color.black,1));
        Eti2.setBounds(64, 352, 224, 160);
        Eti2.setIcon(new ImageIcon(img.getImage().getScaledInstance(Eti2.getWidth(), Eti2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Eti2);
        
        img = new ImageIcon("src/img/Imagen10.png");
        JLabel Eti3 = new JLabel();
        Eti3.setBorder(BorderFactory.createLineBorder(Color.black,1));
        Eti3.setBounds(704, 160, 208, 144);
        Eti3.setIcon(new ImageIcon(img.getImage().getScaledInstance(Eti3.getWidth(), Eti3.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Eti3);
        
        img = new ImageIcon("src/img/Imagen11.png");
        JLabel Eti4 = new JLabel();
        Eti4.setBorder(BorderFactory.createLineBorder(Color.black,1));
        Eti4.setBounds(704, 352, 216, 72);
        Eti4.setIcon(new ImageIcon(img.getImage().getScaledInstance(Eti4.getWidth(), Eti4.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Eti4);
        
        img = new ImageIcon("src/img/Imagen12.png");
        JLabel Eti5 = new JLabel();
        Eti5.setBorder(BorderFactory.createLineBorder(Color.black,1));
        Eti5.setBounds(736, 448, 160, 144);
        Eti5.setIcon(new ImageIcon(img.getImage().getScaledInstance(Eti5.getWidth(), Eti5.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Eti5);
        
        img = new ImageIcon("src/img/Boton14.png");
        Btn2 = new JButton();
        Btn2.setBounds(736, 620, 100, 32);
        Btn2.setIcon(new ImageIcon(img.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        ActionListener Ai = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               CursosAlumno obj = new CursosAlumno();
               obj.setVisible(true);
               dispose();
            }
        };
        Btn2.addActionListener(Ai);
        
        img = new ImageIcon("src/img/Boton13.png");
        Btn3 = new JButton();
        Btn3.setBounds(224, 520, 64, 16);
        Btn3.setIcon(new ImageIcon(img.getImage().getScaledInstance(Btn3.getWidth(), Btn3.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn3);
        
        img = new ImageIcon("src/img/Boton10.png");
        Btn4 = new JButton();
        Btn4.setBounds(64, 608, 32, 32);
        Btn4.setIcon(new ImageIcon(img.getImage().getScaledInstance(Btn4.getWidth(), Btn4.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn4);
        
        JPopupMenu Pm = new JPopupMenu();
        JMenuItem Mi = new JMenuItem("Darse de baja en el curso");
        Mi.setBackground(Color.getHSBColor(247,199,41));
        ActionListener Ai2 = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               SolicitarBajaCurso obj = new SolicitarBajaCurso();
               obj.setVisible(true);
               dispose();
               obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            }
        };
        Mi.addActionListener(Ai2);
        Pm.add(Mi);
        img = new ImageIcon("src/img/Boton17.png");
        Btn5 = new JButton();
        Btn5.setBounds(814, 80, 32, 32);
        Btn5.setIcon(new ImageIcon(img.getImage().getScaledInstance(Btn5.getWidth(), Btn5.getHeight(), Image.SCALE_SMOOTH)));
        Btn5.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                Pm.show(e.getComponent(), e.getX(), e.getY());
            }
        });
        Pnl.add(Btn5);
    }  
}
