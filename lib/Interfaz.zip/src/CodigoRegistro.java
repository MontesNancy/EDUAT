import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import static java.awt.Image.SCALE_SMOOTH;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class CodigoRegistro extends JFrame{
    private JPanel Pnl;
    private JLabel Etq, Etq2, Etq3;
    private JLabel Etqt, Etqt2;
    private JTextField txtf;
    private ImageIcon Lg, img1, img2, img3;
    private JButton Btn1, Btn2, Btn3, Btn4, Btn5, Btn6;
    public static void main(String[] args) {
        CodigoRegistro Ap = new CodigoRegistro();//Ap variable de la aplicacion//
        
    }
    public CodigoRegistro(){
        Panel();
        Logos();
        Imagenes();
        Formulario();
        setVisible(true);
        setTitle("Codigo Registro");
        setSize(1024,720);
        this.setResizable(false);
        setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void Panel(){
        Pnl = new JPanel();
        Pnl.setLayout(null);
        Pnl.setBackground(Color.white);
        this.getContentPane().add(Pnl);
    }
    private void Logos(){
        Etq = new JLabel();
        Etq.setBackground(Color.red);
        Etq.setOpaque(true);
        Etq.setBounds(0, 0, 1024, 56);
        Pnl.add(Etq);
        
        Lg = new ImageIcon("src/img/Logo1.png");
        JButton Blg = new JButton();
        Blg.setBounds(35, 12, 100, 32);
        Blg.setBackground(null);
        Blg.setBorder(BorderFactory.createEmptyBorder());
        Blg.setIcon(new ImageIcon(Lg.getImage().getScaledInstance(Blg.getWidth(), Blg.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Blg);
        
        JTextField tf = new JTextField(" Buscar aqui");
        tf.setFont(new Font("Roboto",0,11));
        tf.setEnabled(false);
        tf.setBounds(576, 18, 320, 20);
        Etq.add(tf);
        
        ImageIcon Icn = new ImageIcon("src/img/Icono1.png");
        JButton Ic = new JButton();
        Ic.setBounds(912, 16, 7, 23);
        Ic.setBackground(null);
        Ic.setBorder(BorderFactory.createEmptyBorder());
        Ic.setIcon(new ImageIcon(Icn.getImage().getScaledInstance(Ic.getWidth(), Ic.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Ic);
    }
    private void Imagenes(){
        img1 = new ImageIcon("src/img/Boton7.png");
        Btn1 = new JButton();
        Btn1.setBounds(416, 576, 176, 40);
        Btn1.setIcon(new ImageIcon(img1.getImage().getScaledInstance(Btn1.getWidth(), Btn1.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn1);
        
        ActionListener Ai = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               RegistroCompleto obj = new RegistroCompleto();
               obj.setVisible(true);
               dispose();
            }
        };
        Btn1.addActionListener(Ai);
        
        img2 = new ImageIcon("src/img/Imagen1.png");
        Etq2 = new JLabel();
        Etq2.setBounds(288, 80, 416, 130);
        Etq2.setIcon(new ImageIcon(img2.getImage().getScaledInstance(Etq2.getWidth(), Etq2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Etq2);
    }
    private void Formulario(){
        Etqt = new JLabel("Código de registro:");
        Etqt.setFont(new Font("Roboto",0,14));
        Etqt.setBounds(256, 224, 200, 25);
        Etqt.setHorizontalAlignment(SwingConstants.CENTER);
        Pnl.add(Etqt);
        
        Etqt = new JLabel("Si el codigo no llega en 5 min, volver a solicitarlo");
        Etqt.setFont(new Font("Roboto",0,12));
        Etqt.setBounds(368, 448, 272, 25);
        Etqt.setHorizontalAlignment(SwingConstants.CENTER);
        Pnl.add(Etqt);
        
        Etqt = new JLabel("Volver a solicitar codigo de registro");
        Etqt.setForeground(Color.blue);
        Etqt.setFont(new Font("Roboto", 0, 12));
        Etqt.setBounds(376, 512, 256, 25);
        Etqt.setHorizontalAlignment(SwingConstants.CENTER);
        Pnl.add(Etqt);
        
        Etqt2 = new JLabel();
        Etqt2.setBackground(Color.gray);
        Etqt2.setOpaque(true);
        Etqt2.setBounds(288, 256, 480, 2);
        Pnl.add(Etqt2);
        
        img3 = new ImageIcon("src/img/Imagen2.png");
        Etq3 = new JLabel();
        Etq3.setBounds(264, 304, 512, 96);
        Etq3.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Etq3.getWidth(), Etq3.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Etq3);
    }
}
