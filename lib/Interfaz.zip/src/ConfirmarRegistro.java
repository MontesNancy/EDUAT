import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import static java.awt.Image.SCALE_SMOOTH;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class ConfirmarRegistro extends JFrame{
    private JPanel Pnl;
    private JLabel Etq, Etq2, Etq3;
    private JLabel Etqt;
    private JTextField txtf;
    private ImageIcon Lg, img1, img2, img3;
    private JButton Btn1;
    public static void main(String[] args) {
        ConfirmarRegistro Ap = new ConfirmarRegistro();//Ap variable de la aplicacion//
        Ap.setVisible(true);
        Ap.setTitle("Confirmar Registro");
    }
    public ConfirmarRegistro(){
        Panel();
        Logos();
        Pantalla();
        setSize(1024,720);
        this.setResizable(false);
        setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void Panel(){
        Pnl = new JPanel();
        Pnl.setLayout(null);
        Pnl.setBackground(Color.white);
        this.getContentPane().add(Pnl);
    }
    private void Logos(){
        Etq = new JLabel();
        Etq.setBackground(Color.red);
        Etq.setOpaque(true);
        Etq.setBounds(0, 0, 1024, 56);
        Pnl.add(Etq);
        
        Lg = new ImageIcon("src/img/Logo1.png");
        JButton Blg = new JButton();
        Blg.setBounds(35, 12, 100, 32);
        Blg.setBackground(null);
        Blg.setBorder(BorderFactory.createEmptyBorder());
        Blg.setIcon(new ImageIcon(Lg.getImage().getScaledInstance(Blg.getWidth(), Blg.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Blg);
        
        JTextField tf = new JTextField(" Buscar aqui");
        tf.setFont(new Font("Roboto",0,11));
        tf.setEnabled(false);
        tf.setBounds(576, 18, 320, 20);
        Etq.add(tf);
        
        ImageIcon Icn = new ImageIcon("src/img/Icono1.png");
        JButton Ic = new JButton();
        Ic.setBounds(912, 16, 7, 23);
        Ic.setBackground(null);
        Ic.setBorder(BorderFactory.createEmptyBorder());
        Ic.setIcon(new ImageIcon(Icn.getImage().getScaledInstance(Ic.getWidth(), Ic.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Ic);
        
        Etq2 = new JLabel();
        Etq2.setBackground(Color.red);
        Etq2.setOpaque(true);
        Etq2.setBounds(0, 640, 1024, 44);
        Pnl.add(Etq2);
    }
    private void Pantalla(){    
        Etqt = new JLabel();
        Etqt.setBackground(Color.gray);
        Etqt.setOpaque(true);
        Etqt.setBounds(0, 128, 1024, 2);
        Pnl.add(Etqt);
        
        Etqt = new JLabel();
        Etqt.setBackground(Color.gray);
        Etqt.setOpaque(true);
        Etqt.setBounds(0, 512, 1024, 2);
        Pnl.add(Etqt);
        
        Etq2 = new JLabel("Registro Docentes");
        Etq2.setFont(new Font("Arial",0,18));
        Etq2.setBounds(416, 80, 160, 24);
        Pnl.add(Etq2);
        
        Etq3 = new JLabel("¿Enviar datos de solicitud de registro?");
        Etq3.setFont(new Font("Arial",0,13));
        Etq3.setBounds(368, 192, 416, 24);
        Pnl.add(Etq3);
        
        JCheckBox ch = new JCheckBox("Confirmar envio de datos");
        ch.setBackground(null);
        ch.setFont(new Font("Arial",0,13));
        ch.setBounds(384, 256, 256, 24);
        Pnl.add(ch);
        
        img1 = new ImageIcon("src/img/Boton7.png");
        Btn1 = new JButton();
        Btn1.setBounds(528, 560, 176, 40);
        Btn1.setIcon(new ImageIcon(img1.getImage().getScaledInstance(Btn1.getWidth(), Btn1.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn1);
        ActionListener Ai = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               CodigoRegistro obj = new CodigoRegistro();
               obj.setVisible(true);
               dispose();
            }
        };
        Btn1.addActionListener(Ai);
        img1 = new ImageIcon("src/img/Boton14.png");
        Btn1 = new JButton();
        Btn1.setBounds(288, 560, 176, 40);
        Btn1.setIcon(new ImageIcon(img1.getImage().getScaledInstance(Btn1.getWidth(), Btn1.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn1);
        ActionListener Ai2 = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               RegistroDocentes obj = new RegistroDocentes();
               obj.setVisible(true);
               dispose();
            }
        };
        Btn1.addActionListener(Ai2);
    }
}
