import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import static java.awt.Image.SCALE_SMOOTH;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class IniciarSesion extends JFrame{
    private JPanel Pnl;
    private JLabel Etq, Etq2, Etq3;
    private JLabel Etqt, Etqt2;
    private JTextField txtf;
    private ImageIcon Lg, img1, img2, img3, img4, img5, img6, img7;
    private JButton Btn1, Btn2, Btn3, Btn4, Btn5, Btn6, Btn7;
    public static void main(String[] args) {
        IniciarSesion Ap = new IniciarSesion();//Ap variable de la aplicacion//
        Ap.setVisible(true);
        Ap.setTitle("Iniciar Sesion");
    }
    public IniciarSesion(){
        Panel();
        Logos();
        Imagenes();
        Formulario();
        setSize(1024,720);
        this.setResizable(false);
        setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void Panel(){
        Pnl = new JPanel();
        Pnl.setLayout(null);
        Pnl.setBackground(Color.white);
        this.getContentPane().add(Pnl);
    }
    private void Logos(){
        Etq = new JLabel();
        Etq.setBackground(Color.red);
        Etq.setOpaque(true);
        Etq.setBounds(0, 0, 1024, 56);
        Pnl.add(Etq);
        
        Lg = new ImageIcon("src/img/Logo1.png");
        JButton Blg = new JButton();
        Blg.setBounds(35, 12, 100, 32);
        Blg.setBackground(null);
        Blg.setBorder(BorderFactory.createEmptyBorder());
        Blg.setIcon(new ImageIcon(Lg.getImage().getScaledInstance(Blg.getWidth(), Blg.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Blg);
        
        JTextField tf = new JTextField(" Buscar aqui");
        tf.setFont(new Font("Roboto",0,11));
        tf.setEnabled(false);
        tf.setBounds(576, 18, 320, 20);
        Etq.add(tf);
        
        ImageIcon Icn = new ImageIcon("Icono1.png");
        JButton Ic = new JButton();
        Ic.setBounds(912, 16, 7, 23);
        Ic.setBackground(null);
        Ic.setBorder(BorderFactory.createEmptyBorder());
        Ic.setIcon(new ImageIcon(Icn.getImage().getScaledInstance(Ic.getWidth(), Ic.getHeight(), Image.SCALE_SMOOTH)));
        Etq.add(Ic);
        
        Etq2 = new JLabel();
        Etq2.setBackground(Color.red);
        Etq2.setOpaque(true);
        Etq2.setBounds(0, 640, 1024, 44);
        Pnl.add(Etq2);
    }
    private void Imagenes(){
        img1 = new ImageIcon("src/img/Boton1 - 1.png");
        Btn1 = new JButton();
        Btn1.setBounds(724, 272, 192, 38);
        Btn1.setIcon(new ImageIcon(img1.getImage().getScaledInstance(Btn1.getWidth(), Btn1.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn1);
        
        img2 = new ImageIcon("src/img/Boton2 - 1.png");
        Btn2 = new JButton();
        Btn2.setBounds(724, 320, 192, 38);
        Btn2.setIcon(new ImageIcon(img2.getImage().getScaledInstance(Btn2.getWidth(), Btn2.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn2);
        
        img3 = new ImageIcon("src/img/Boton3 - 1.png");
        Btn3 = new JButton();
        Btn3.setBounds(724, 368, 192, 38);
        Btn3.setIcon(new ImageIcon(img3.getImage().getScaledInstance(Btn3.getWidth(), Btn3.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn3);
        
        img4 = new ImageIcon("src/img/Boton4 - 1.png");
        Btn4 = new JButton();
        Btn4.setBounds(724, 416, 192, 38);
        Btn4.setIcon(new ImageIcon(img4.getImage().getScaledInstance(Btn4.getWidth(), Btn4.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn4);
        
        img5 = new ImageIcon("src/img/Boton20.png");
        Btn5 = new JButton();
        Btn5.setBounds(48, 368, 128, 40);
        Btn5.setIcon(new ImageIcon(img5.getImage().getScaledInstance(Btn5.getWidth(), Btn5.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn5);
        
        img5 = new ImageIcon("src/img/Boton21.png");
        Btn5 = new JButton();
        Btn5.setBounds(48, 432, 256, 24);
        Btn5.setIcon(new ImageIcon(img5.getImage().getScaledInstance(Btn5.getWidth(), Btn5.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn5);
        
        Etq3 = new JLabel("¿No se ha registrado?");
        Etq3.setFont(new Font("Roboto",0,14));
        Etq3.setBounds(16, 464, 200, 24);
        Etq3.setHorizontalAlignment(SwingConstants.CENTER);
        Pnl.add(Etq3);
        
        img6 = new ImageIcon("src/img/Boton22.png");
        Btn6 = new JButton();
        Btn6.setBounds(48, 512, 128, 36);
        Btn6.setIcon(new ImageIcon(img6.getImage().getScaledInstance(Btn6.getWidth(), Btn6.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Btn6);
        
        img7 = new ImageIcon("src/img/Icono10.png");
        Etq3 = new JLabel();
        Etq3.setBounds(768, 144, 96, 88);
        Etq3.setIcon(new ImageIcon(img7.getImage().getScaledInstance(Etq3.getWidth(), Etq3.getHeight(), Image.SCALE_SMOOTH)));
        Pnl.add(Etq3);
        
        Etq3 = new JLabel("Iniciar Sesión con:");
        Etq3.setFont(new Font("Roboto",1,16));
        Etq3.setBounds(720, 228, 200, 24);
        Etq3.setHorizontalAlignment(SwingConstants.CENTER);
        Pnl.add(Etq3);
    }
    private void Formulario(){
        Etqt = new JLabel();
        Etqt.setText("Iniciar Sesión");
        Etqt.setFont(new Font("Roboto",0,18));
        Etqt.setBounds(336, 96, 200, 25);
        Etqt.setHorizontalAlignment(SwingConstants.RIGHT);
        Pnl.add(Etqt);

        Etqt2 = new JLabel("Nombre de usuario:");
        Etqt2.setFont(new Font("Arial",0,18));
        Etqt2.setBounds(48, 160, 200, 25);
        Etqt2.setHorizontalAlignment(SwingConstants.LEFT);
        Pnl.add(Etqt2);
        
        txtf = new JTextField();
        txtf.setBounds(48, 200, 240, 24);
        Pnl.add(txtf);
        
        Etqt2 = new JLabel("Contraseña:");
        Etqt2.setFont(new Font("Arial",0,18));
        Etqt2.setBounds(48, 240, 200, 25);
        Etqt2.setHorizontalAlignment(SwingConstants.LEFT);
        Pnl.add(Etqt2);
        
        txtf = new JTextField();
        txtf.setBounds(48, 280, 240, 24);
        Pnl.add(txtf);
        
        JCheckBox Ch = new JCheckBox("Mantener Sesion Iniciada");
        Ch.setFont(new Font("Roboto",0,14));
        Ch.setBackground(null);
        Ch.setBounds(48, 336, 256, 20);
        Pnl.add(Ch);
    }
}
